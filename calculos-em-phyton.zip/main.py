#declarando variaveis
n1 = int(input('Digite um numero: '))
n2 = input(input('Digite outro numero: '))
r1 = n1-1
r2 = n1+1
r6 = r2/2
r3 = n1*2 
r4 = n1*3 
r5 = n1**(1/2)
print('O valor antecessor é {} e o valor sucessor é {}'.format(r1,r2))
print('o valor do dobro é {} , o valor do tiplo é {} e o valor da raiz quadrada é {}'.format(r3,r4,r5))
print('A media do aluno é {}'.format(r6))
