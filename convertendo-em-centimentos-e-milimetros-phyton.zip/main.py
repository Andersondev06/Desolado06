#declarando variaveis
n1 = int(input('Digite quantos metros: '))
n2 = n1*100
n3 = n1*1000
print('Em centimetros da {}cm e em mmilimetros da {}mm'.format(n2,n3))