#declarando variaveis
n = (input('Digite algo : '))
print('1-',n.isnumeric())
#se o é numero ou não
print('2-',n.isalpha())
#se é texto ou não
print('3-',n.isalnum())
#se é numero e letra juntos
print('4-',n.isupper())
#se existe letra maiuscula
print('5-',n.isspace())
#se existe espaço 
