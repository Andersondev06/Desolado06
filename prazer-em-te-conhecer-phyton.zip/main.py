#declarando variaveis
nome = input('Digite seu nome: ')
print('Prazer em te conhecer, ', nome, '!, seja bem vindo')
