# decalrando variaveis
numero1 = int(input('Digite um numero:  '))
numero2 = int(input('Digite outro numero:  '))
resultado = numero1 + numero2
print('sua soma é igual a: ', resultado)
    

  





