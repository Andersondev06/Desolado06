#declarando variaveis
n1 = int(input('Digite o numero: '))
n2 = n1*1
n3 = n1*2 
n4 = n1*3 
n5 = n1*4 
n6 = n1*5 
n7 = n1*6 
n8 = n1*7 
n9 = n1*8 
n10 = n1*9
n11 = n1*10
print('a tabuada desse numero é: {}\n{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}'.format(n2,n3,n4,n5,n6,n7,n8,n9,n10,n11))